#!/usr/bin/env python3
"""
AUTO TRADING VERSION - Enhanced VIX + AD ASTRA Bot
Automatically trades during market hours in your Alpaca paper account
"""

import os
import threading
import time
from datetime import datetime, timezone, time as dt_time
import pytz
from vix_ad_astra_enhanced_bot import VIXAdAstraEnhancedBot

class AutoTradingBot(VIXAdAstraEnhancedBot):
    def __init__(self):
        super().__init__()
        
        # Auto trading settings
        self.auto_trading_enabled = True
        self.simulation_mode = False  # DISABLE simulation for real paper trading
        self.real_trading_enabled = True  # ENABLE real trading
        
        # Market hours (Eastern Time)
        self.market_timezone = pytz.timezone('US/Eastern')
        self.market_open_time = dt_time(9, 30)  # 9:30 AM ET
        self.market_close_time = dt_time(16, 0)  # 4:00 PM ET
        
        # Auto trading controls
        self.trading_active = False
        self.market_hours_only = True
        self.max_daily_trades = 50  # Safety limit
        self.daily_trade_count = 0
        self.last_trade_date = None
        
        self.log("🤖 AUTO TRADING BOT INITIALIZED")
        self.log(f"📊 Mode: {'LIVE PAPER TRADING' if not self.simulation_mode else 'SIMULATION'}")
        self.log(f"⏰ Market Hours Only: {self.market_hours_only}")
        self.log(f"🛡️ Daily Trade Limit: {self.max_daily_trades}")

    def is_market_hours(self):
        """Check if current time is during market hours"""
        now = datetime.now(self.market_timezone)
        current_time = now.time()
        current_weekday = now.weekday()  # 0=Monday, 6=Sunday
        
        # Check if it's a weekday (Monday=0 to Friday=4)
        is_weekday = current_weekday < 5
        
        # Check if within trading hours
        is_trading_hours = self.market_open_time <= current_time <= self.market_close_time
        
        return is_weekday and is_trading_hours

    def should_trade(self):
        """Determine if we should execute trades right now"""
        # Reset daily counter if new day
        today = datetime.now().date()
        if self.last_trade_date != today:
            self.daily_trade_count = 0
            self.last_trade_date = today
        
        # Check all conditions
        conditions = {
            'connected': self.connected,
            'auto_enabled': self.auto_trading_enabled,
            'market_hours': not self.market_hours_only or self.is_market_hours(),
            'daily_limit': self.daily_trade_count < self.max_daily_trades,
            'real_trading': self.real_trading_enabled and not self.simulation_mode
        }
        
        all_good = all(conditions.values())
        
        if not all_good:
            failed_conditions = [k for k, v in conditions.items() if not v]
            if len(failed_conditions) <= 2:  # Only log if few conditions failed
                self.log(f"⏸️  Trading paused: {', '.join(failed_conditions)}")
        
        return all_good

    def execute_real_trade(self, signal_data):
        """Execute a real trade in Alpaca paper account"""
        try:
            symbol = signal_data['symbol']
            action = signal_data['action']
            quantity = signal_data['quantity']
            price = signal_data.get('price', None)
            
            self.log(f"🎯 EXECUTING REAL TRADE: {action} {quantity} {symbol}")
            
            # Handle stock trades
            if action == 'BUY':
                side = 'buy'
                return self._execute_stock_order(symbol, side, quantity)
            elif action == 'SELL':
                side = 'sell'
                return self._execute_stock_order(symbol, side, quantity)
            # Handle options trades
            elif action in ['BUY_CALL', 'SELL_CALL', 'BUY_PUT', 'SELL_PUT']:
                return self._execute_options_order(symbol, action, quantity, signal_data)
            else:
                self.log(f"❌ Unknown action: {action}")
                return False
            
        except Exception as e:
            self.log(f"❌ TRADE EXECUTION FAILED: {str(e)}")
            return False

    def _execute_stock_order(self, symbol, side, quantity):
        """Execute stock order"""
        try:
            order = self.api.submit_order(
                symbol=symbol,
                qty=quantity,
                side=side,
                type='market',
                time_in_force='day'
            )
            
            self.daily_trade_count += 1
            
            self.log(f"✅ STOCK TRADE EXECUTED:")
            self.log(f"   📋 Order ID: {order.id}")
            self.log(f"   📈 {side.upper()} {quantity} {symbol}")
            self.log(f"   💰 Status: {order.status}")
            self.log(f"   📊 Daily trades: {self.daily_trade_count}/{self.max_daily_trades}")
            
            return True
            
        except Exception as e:
            self.log(f"❌ Stock order failed: {str(e)}")
            return False

    def _execute_options_order(self, symbol, action, quantity, signal_data):
        """Execute options order"""
        try:
            # Get options contract symbol
            contract_symbol = self._get_options_contract(symbol, action, signal_data)
            
            if not contract_symbol:
                self.log(f"❌ Could not find options contract for {symbol}")
                return False
            
            # Map action to order side
            if action in ['BUY_CALL', 'BUY_PUT']:
                side = 'buy'
            else:  # SELL_CALL, SELL_PUT
                side = 'sell'
            
            # Execute options order
            order = self.api.submit_order(
                symbol=contract_symbol,
                qty=quantity,
                side=side,
                type='market',
                time_in_force='day'
            )
            
            self.daily_trade_count += 1
            
            self.log(f"✅ OPTIONS TRADE EXECUTED:")
            self.log(f"   📋 Order ID: {order.id}")
            self.log(f"   🎯 {action} {quantity} contracts")
            self.log(f"   📑 Contract: {contract_symbol}")
            self.log(f"   💰 Status: {order.status}")
            self.log(f"   📊 Daily trades: {self.daily_trade_count}/{self.max_daily_trades}")
            
            return True
            
        except Exception as e:
            self.log(f"❌ Options order failed: {str(e)}")
            return False

    def _get_options_contract(self, symbol, action, signal_data):
        """Get appropriate options contract symbol"""
        try:
            # Get current stock price for strike selection
            current_price = signal_data.get('entry_price', 0)
            if current_price == 0:
                # Fallback to current market price
                quote = self.api.get_latest_quote(symbol)
                current_price = float(quote.ask_price)
            
            # Determine option type
            option_type = 'C' if 'CALL' in action else 'P'
            
            # Select strike price (ATM, slightly OTM based on direction)
            if action in ['BUY_CALL', 'SELL_PUT']:  # Bullish
                strike = self._round_to_strike(current_price * 1.02)  # Slightly OTM calls
            else:  # BUY_PUT, SELL_CALL - Bearish
                strike = self._round_to_strike(current_price * 0.98)  # Slightly OTM puts
            
            # Get expiration date (default to next Friday)
            expiration = self._get_next_friday()
            
            # Build options contract symbol (OCC format)
            # Format: SYMBOL + YYMMDD + C/P + STRIKE (8 digits with 3 decimals)
            strike_str = f"{int(strike * 1000):08d}"
            contract_symbol = f"{symbol}{expiration}{option_type}{strike_str}"
            
            self.log(f"🎯 Options Contract: {contract_symbol}")
            self.log(f"   📊 Strike: ${strike} | Type: {option_type} | Exp: {expiration}")
            
            return contract_symbol
            
        except Exception as e:
            self.log(f"❌ Options contract lookup failed: {str(e)}")
            return None

    def _round_to_strike(self, price):
        """Round price to nearest standard strike price"""
        if price < 50:
            return round(price * 2) / 2  # $0.50 increments
        elif price < 200:
            return round(price)  # $1.00 increments
        else:
            return round(price / 5) * 5  # $5.00 increments

    def _get_next_friday(self):
        """Get next Friday expiration in YYMMDD format"""
        import datetime
        today = datetime.date.today()
        days_until_friday = (4 - today.weekday()) % 7
        if days_until_friday == 0:  # If today is Friday, get next week
            days_until_friday = 7
        
        next_friday = today + datetime.timedelta(days=days_until_friday)
        return next_friday.strftime("%y%m%d")

    def enhanced_signal_filter(self, signal_data):
        """Enhanced filtering with real trading considerations"""
        if not self.should_trade():
            return None
            
        # Apply parent class filtering first
        filtered_signal = super().enhanced_signal_filter(signal_data)
        
        if filtered_signal and self.real_trading_enabled:
            # Additional safety checks for real trading
            confidence = filtered_signal.get('confidence', 0)
            
            # Higher confidence threshold for real trades
            min_confidence = 75.0  # Require 75%+ confidence for real trades
            
            if confidence < min_confidence:
                self.log(f"⚠️  Signal filtered - confidence {confidence:.1f}% < {min_confidence}%")
                return None
            
            self.log(f"🎯 REAL TRADE SIGNAL APPROVED: {confidence:.1f}% confidence")
            
        return filtered_signal

    def process_trading_signal(self, signal_data):
        """Process trading signal - execute real or simulated trade"""
        if not signal_data:
            return
            
        if self.real_trading_enabled and not self.simulation_mode:
            # Execute real trade
            success = self.execute_real_trade(signal_data)
            if success:
                self.log(f"💰 REAL TRADE P&L will be reflected in account")
            else:
                self.log(f"❌ Real trade failed - check logs")
        else:
            # Fall back to simulation
            super().process_trading_signal(signal_data)

    def get_market_status(self):
        """Get detailed market status"""
        now = datetime.now(self.market_timezone)
        is_market_hours = self.is_market_hours()
        
        if is_market_hours:
            status = "🟢 MARKET OPEN"
        else:
            weekday = now.weekday()
            if weekday >= 5:  # Weekend
                status = "🔴 MARKET CLOSED (Weekend)"
            else:
                current_time = now.time()
                if current_time < self.market_open_time:
                    status = "🟡 PRE-MARKET"
                else:
                    status = "🔴 AFTER HOURS"
        
        return {
            'status': status,
            'current_time_et': now.strftime('%H:%M:%S ET'),
            'is_trading_hours': is_market_hours,
            'can_trade': self.should_trade()
        }

    def start_auto_trading(self):
        """Start the auto trading bot"""
        self.log("🚀 STARTING AUTO TRADING BOT")
        
        market_status = self.get_market_status()
        self.log(f"📊 Market Status: {market_status['status']}")
        self.log(f"⏰ Current Time: {market_status['current_time_et']}")
        
        if market_status['can_trade']:
            self.log("✅ AUTO TRADING ACTIVE - Will place real orders")
        else:
            self.log("⏸️  AUTO TRADING WAITING - Will activate during market hours")
        
        # Start the enhanced bot
        self.start()

# Create global auto trading bot instance
auto_bot = AutoTradingBot()

def start_auto_trading():
    """Start the auto trading bot"""
    auto_bot.start_auto_trading()

if __name__ == "__main__":
    start_auto_trading() 