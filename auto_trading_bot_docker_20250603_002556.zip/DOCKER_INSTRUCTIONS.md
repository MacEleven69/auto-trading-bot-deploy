# 🐳 DOCKER DEPLOYMENT INSTRUCTIONS

## 1. Quick Setup Commands:

```bash
# Upload and extract
scp auto_trading_bot_docker_*.zip root@YOUR_SERVER_IP:/root/
ssh root@YOUR_SERVER_IP
cd /root
unzip auto_trading_bot_docker_*.zip
cd vultr_docker_deployment

# Deploy with Docker
bash deploy.sh

# Edit API keys
nano .env

# Restart with new keys
docker-compose restart
```

## 2. Management Commands:

```bash
cd /root/auto_trading_bot

# Check status
docker-compose ps

# View logs
docker-compose logs -f

# Restart bot
docker-compose restart

# Stop bot
docker-compose down

# Start bot
docker-compose up -d

# Rebuild container
docker-compose build --no-cache
```

## 3. Alternative Management:

```bash
# Use the management script
./manage.sh start     # Start bot
./manage.sh stop      # Stop bot  
./manage.sh restart   # Restart bot
./manage.sh status    # Check status
./manage.sh logs      # View logs
./manage.sh dashboard # Get dashboard URL
```

## 4. Dashboard Access:

```
http://YOUR_SERVER_IP:8893
```

## 5. Firewall Setup:

```bash
ufw allow 8893
```

## 6. Auto-start on Boot:

Docker containers with `restart: unless-stopped` will automatically start when the server reboots.
