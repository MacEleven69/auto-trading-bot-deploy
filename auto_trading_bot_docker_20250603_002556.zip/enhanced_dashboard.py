#!/usr/bin/env python3
"""
Enhanced VIX + AD ASTRA Dashboard Server
Comprehensive dashboard for smart money tracking and enhanced trading features
"""

import json
import http.server
import socketserver
import webbrowser
from vix_ad_astra_enhanced_bot import enhanced_bot

class EnhancedDashboardHandler(http.server.SimpleHTTPRequestHandler):
    """Enhanced HTTP handler for the comprehensive trading dashboard"""
    
    def do_GET(self):
        if self.path == '/':
            self.send_enhanced_dashboard()
        elif self.path == '/api/status':
            self.send_json(enhanced_bot.get_enhanced_status())
        elif self.path == '/api/start':
            enhanced_bot.is_running = True
            enhanced_bot.log("🚀 ===== ENHANCED BOT STARTED BY USER =====")
            self.send_json({'status': 'started'})
        elif self.path == '/api/stop':
            enhanced_bot.is_running = False
            enhanced_bot.log("⏹️ ===== ENHANCED BOT STOPPED BY USER =====")
            self.send_json({'status': 'stopped'})
        elif self.path == '/api/watchlist':
            self.send_json(self.get_watchlist_data())
        elif self.path == '/api/smart-money':
            self.send_json(self.get_smart_money_data())
        else:
            super().do_GET()
    
    def send_json(self, data):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())
    
    def get_watchlist_data(self):
        """Get enhanced watchlist data"""
        return {
            'symbols': [
                {
                    'symbol': symbol,
                    'name': data.name,
                    'sector': data.sector,
                    'price': data.current_price,
                    'smart_score': data.smart_money_score,
                    'unusual_activity': data.unusual_activity,
                    'last_flow': data.last_flow_detected.isoformat() if data.last_flow_detected else None
                }
                for symbol, data in enhanced_bot.watchlist.items()
            ]
        }
    
    def get_smart_money_data(self):
        """Get smart money flow summary"""
        from datetime import datetime, timedelta
        
        recent_flows = [
            f for f in enhanced_bot.detected_flows
            if (datetime.now() - f.timestamp).seconds < 3600  # Last hour
        ]
        
        return {
            'recent_flows': [
                {
                    'symbol': f.symbol,
                    'type': f.flow_type.value,
                    'direction': f.direction.value,
                    'premium': f.premium,
                    'confidence': f.confidence,
                    'timestamp': f.timestamp.isoformat()
                }
                for f in recent_flows[-20:]  # Last 20 flows
            ],
            'total_institutional': len(enhanced_bot.institutional_activity),
            'options_signals': enhanced_bot.options_flow_signals
        }
    
    def send_enhanced_dashboard(self):
        """Send comprehensive enhanced dashboard"""
        html = '''<!DOCTYPE html>
<html>
<head>
    <title>VIX + AD ASTRA Enhanced Trading Bot</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { 
            font-family: 'Consolas', 'Courier New', monospace; 
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 100%); 
            color: #00ff00; 
            padding: 10px;
            font-size: 12px;
            line-height: 1.3;
            min-height: 100vh;
        }
        
        .header { 
            text-align: center; 
            padding: 20px; 
            border: 2px solid #00ff00; 
            margin-bottom: 15px;
            background: linear-gradient(45deg, #001100, #002200);
            border-radius: 8px;
        }
        .header h1 { 
            color: #ffff00; 
            font-size: 28px; 
            text-shadow: 0 0 10px #ffff00;
            margin-bottom: 5px;
        }
        .header .subtitle { 
            color: #00ffff; 
            font-size: 16px;
            margin: 5px 0;
        }
        .header .features { 
            color: #ff6b6b; 
            font-size: 14px;
            margin-top: 10px;
        }
        
        .controls { 
            text-align: center; 
            margin-bottom: 15px; 
            padding: 15px;
            border: 1px solid #444;
            background: rgba(0, 20, 0, 0.5);
            border-radius: 5px;
        }
        .btn { 
            background: linear-gradient(45deg, #003300, #005500); 
            color: #00ff00; 
            border: 2px solid #00ff00; 
            padding: 12px 24px; 
            margin: 0 8px; 
            cursor: pointer; 
            font-family: inherit;
            font-size: 14px;
            font-weight: bold;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .btn:hover { 
            background: #00ff00; 
            color: #000; 
            box-shadow: 0 0 15px #00ff00;
        }
        
        .dashboard-grid { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 15px; 
            margin-bottom: 15px; 
        }
        
        .stats-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); 
            gap: 10px; 
            margin-bottom: 15px; 
        }
        
        .stat-box { 
            border: 1px solid #00ff00; 
            padding: 12px; 
            background: linear-gradient(135deg, #001a00, #003300);
            border-radius: 5px;
            font-family: monospace;
        }
        .stat-title { 
            color: #ffff00; 
            font-weight: bold; 
            font-size: 16px;
            border-bottom: 1px solid #444;
            padding-bottom: 5px;
            margin-bottom: 8px;
            text-shadow: 0 0 5px #ffff00;
        }
        .stat-line { margin: 3px 0; }
        .stat-value { font-weight: bold; }
        .positive { color: #00ff00; }
        .negative { color: #ff4444; }
        .neutral { color: #ffff00; }
        .institutional { color: #ff6b6b; }
        .warning { color: #ffa500; }
        
        .watchlist-container {
            border: 2px solid #00ffff;
            padding: 15px;
            background: linear-gradient(135deg, #001a1a, #003333);
            border-radius: 5px;
        }
        
        .watchlist-title {
            color: #00ffff;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 15px;
            text-align: center;
            text-shadow: 0 0 5px #00ffff;
        }
        
        .symbol-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 8px;
        }
        
        .symbol-card {
            border: 1px solid #666;
            padding: 8px;
            background: rgba(0, 30, 30, 0.7);
            border-radius: 3px;
            font-size: 11px;
        }
        
        .symbol-card.active {
            border-color: #ff6b6b;
            background: rgba(50, 20, 20, 0.7);
        }
        
        .symbol-header {
            font-weight: bold;
            color: #00ffff;
            margin-bottom: 3px;
        }
        
        .smart-money-section {
            border: 2px solid #ff6b6b;
            padding: 15px;
            background: linear-gradient(135deg, #1a0000, #330000);
            border-radius: 5px;
        }
        
        .smart-money-title {
            color: #ff6b6b;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 15px;
            text-align: center;
            text-shadow: 0 0 5px #ff6b6b;
        }
        
        .flow-item {
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #444;
            background: rgba(20, 0, 0, 0.5);
            border-radius: 3px;
            font-size: 11px;
        }
        
        .flow-institutional {
            border-color: #ff6b6b;
            background: rgba(50, 20, 20, 0.7);
        }
        
        .live-feed { 
            border: 2px solid #00ff00; 
            height: 400px; 
            overflow-y: auto; 
            padding: 15px; 
            background: rgba(0, 0, 0, 0.8);
            border-radius: 5px;
            white-space: pre-wrap;
            font-size: 11px;
            font-family: 'Consolas', monospace;
        }
        .live-feed::-webkit-scrollbar { width: 12px; }
        .live-feed::-webkit-scrollbar-track { 
            background: #333; 
            border-radius: 5px;
        }
        .live-feed::-webkit-scrollbar-thumb { 
            background: linear-gradient(45deg, #00ff00, #00aa00); 
            border-radius: 5px; 
        }
        
        .status-bar {
            text-align: center;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #666;
            background: linear-gradient(45deg, #111, #222);
            border-radius: 5px;
            font-weight: bold;
        }
        .connected { color: #00ff00; text-shadow: 0 0 5px #00ff00; }
        .disconnected { color: #ff4444; text-shadow: 0 0 5px #ff4444; }
        .running { color: #00ff00; text-shadow: 0 0 5px #00ff00; }
        .stopped { color: #ff4444; text-shadow: 0 0 5px #ff4444; }
        
        .alert-box {
            background: linear-gradient(45deg, #330000, #550000);
            border: 2px solid #ff4444;
            color: #ffffff;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
        }
        
        .metric-highlight {
            background: linear-gradient(45deg, #002200, #004400);
            border: 1px solid #00ff00;
            padding: 5px 10px;
            border-radius: 3px;
            display: inline-block;
            margin: 2px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🤖 VIX + AD ASTRA Enhanced Trading Bot</h1>
        <div class="subtitle">Advanced Smart Money Tracking & Options Flow Analysis</div>
        <div class="features">✨ Multi-Stock Watchlist | 🏛️ Institutional Activity | ⚡ Options Flow | 🧠 VIX Intelligence</div>
    </div>

    <div class="status-bar">
        <span>🔗 Connection: </span><span id="connection-status">Checking...</span>
        <span style="margin-left: 30px;">🤖 Bot: </span><span id="bot-status">Loading...</span>
        <span style="margin-left: 30px;" id="uptime-display">⏰ Uptime: --</span>
        <span style="margin-left: 30px;">📊 Cycle: </span><span id="cycle-count">--</span>
    </div>

    <div class="controls">
        <button class="btn" onclick="startBot()">▶️ START ENHANCED BOT</button>
        <button class="btn" onclick="stopBot()">⏹️ STOP BOT</button>
        <button class="btn" onclick="refreshData()">🔄 REFRESH</button>
        <button class="btn" onclick="clearFeed()">🗑️ CLEAR FEED</button>
    </div>

    <div class="stats-grid">
        <div class="stat-box">
            <div class="stat-title">💰 PORTFOLIO STATUS</div>
            <div class="stat-line">Total Value: $<span id="portfolio" class="stat-value">--</span></div>
            <div class="stat-line">Available Cash: $<span id="cash" class="stat-value">--</span></div>
            <div class="stat-line"><strong>REAL Position P&L:</strong> $<span id="real-pnl" class="stat-value">--</span></div>
            <div class="stat-line" id="sim-pnl-line"><em>Simulated P&L:</em> $<span id="sim-pnl" class="stat-value">--</span></div>
        </div>
        
        <div class="stat-box">
            <div class="stat-title">📈 MARKET DATA</div>
            <div class="stat-line">SPY Price: $<span id="spy" class="stat-value">--</span></div>
            <div class="stat-line">VIX Level: <span id="vix" class="stat-value">--</span></div>
            <div class="stat-line">Watchlist: <span id="watchlist-count" class="stat-value">--</span> symbols</div>
            <div class="stat-line">Active Tracking: <span id="active-symbols" class="stat-value">--</span></div>
        </div>
        
        <div class="stat-box">
            <div class="stat-title">🧠 SMART MONEY SIGNALS</div>
            <div class="stat-line">Total Signals: <span id="smart-signals" class="stat-value">--</span></div>
            <div class="stat-line">Institutional: <span id="institutional-signals" class="institutional stat-value">--</span></div>
            <div class="stat-line">Options Flow: <span id="options-signals" class="stat-value">--</span></div>
            <div class="stat-line">Unusual Activity: <span id="unusual-activity" class="warning stat-value">--</span></div>
        </div>
        
        <div class="stat-box">
            <div class="stat-title">🎯 TRADING PERFORMANCE</div>
            <div class="stat-line">Generated: <span id="signals" class="stat-value">--</span></div>
            <div class="stat-line">Approved: <span id="approved" class="stat-value">--</span></div>
            <div class="stat-line">Win Rate: <span id="winrate" class="stat-value">--%</span></div>
            <div class="stat-line">Approval Rate: <span id="approval-rate" class="stat-value">--%</span></div>
        </div>
    </div>

    <div class="dashboard-grid">
        <div class="watchlist-container">
            <div class="watchlist-title">📊 MULTI-STOCK WATCHLIST</div>
            <div id="watchlist-grid" class="symbol-grid">
                <!-- Watchlist symbols will be populated here -->
            </div>
        </div>
        
        <div class="smart-money-section">
            <div class="smart-money-title">🔥 SMART MONEY FLOWS</div>
            <div id="smart-money-flows">
                <!-- Smart money flows will be populated here -->
            </div>
        </div>
    </div>

    <div class="live-feed" id="live-feed">
        [Starting] VIX + AD ASTRA Enhanced Trading Bot
        [Info] Initializing smart money tracking systems...
        [Info] Loading multi-stock watchlist...
        [Info] Waiting for enhanced bot data...
    </div>

    <script>
        let lastUpdateTime = 0;
        
        function updateDashboard() {
            fetch('/api/status')
                .then(response => response.json())
                .then(data => {
                    // Update connection status
                    const connStatus = document.getElementById('connection-status');
                    connStatus.textContent = data.connected ? 'CONNECTED' : 'SIMULATED';
                    connStatus.className = data.connected ? 'connected' : 'disconnected';
                    
                    // Update bot status
                    const botStatus = document.getElementById('bot-status');
                    botStatus.textContent = data.running ? 'RUNNING' : 'STOPPED';
                    botStatus.className = data.running ? 'running' : 'stopped';
                    
                    // Update basic info
                    document.getElementById('uptime-display').textContent = 'Uptime: ' + data.uptime;
                    document.getElementById('cycle-count').textContent = data.cycle_count;
                    
                    // Update portfolio
                    document.getElementById('portfolio').textContent = data.portfolio_value.toFixed(2);
                    document.getElementById('cash').textContent = data.available_cash.toFixed(2);
                    
                    // Real P&L (from actual positions)
                    const realPnl = document.getElementById('real-pnl');
                    realPnl.textContent = (data.real_position_pnl >= 0 ? '+' : '') + data.real_position_pnl.toFixed(2);
                    realPnl.className = 'stat-value ' + (data.real_position_pnl >= 0 ? 'positive' : 'negative');
                    
                    // Simulated P&L (from fake trades) - only show if in simulation mode
                    const simPnlLine = document.getElementById('sim-pnl-line');
                    const simPnl = document.getElementById('sim-pnl');
                    if (data.simulation_mode) {
                        simPnlLine.style.display = 'block';
                        simPnl.textContent = (data.total_pnl >= 0 ? '+' : '') + data.total_pnl.toFixed(2);
                        simPnl.className = 'stat-value ' + (data.total_pnl >= 0 ? 'positive' : 'negative');
                    } else {
                        simPnlLine.style.display = 'none';
                    }
                    
                    // Update market data
                    document.getElementById('spy').textContent = data.spy_price.toFixed(2);
                    document.getElementById('vix').textContent = data.vix_level.toFixed(2);
                    document.getElementById('watchlist-count').textContent = data.watchlist_count;
                    document.getElementById('active-symbols').textContent = data.active_symbols;
                    
                    // Update smart money stats
                    document.getElementById('smart-signals').textContent = data.smart_money_signals;
                    document.getElementById('institutional-signals').textContent = data.institutional_signals;
                    document.getElementById('options-signals').textContent = data.options_flow_signals;
                    document.getElementById('unusual-activity').textContent = data.unusual_activity_symbols;
                    
                    // Update trading stats
                    document.getElementById('signals').textContent = data.signals_generated;
                    document.getElementById('approved').textContent = data.signals_approved;
                    
                    const winRate = document.getElementById('winrate');
                    winRate.textContent = data.win_rate.toFixed(1) + '%';
                    winRate.className = 'stat-value ' + (data.win_rate >= 70 ? 'positive' : data.win_rate >= 50 ? 'neutral' : 'negative');
                    
                    document.getElementById('approval-rate').textContent = data.approval_rate.toFixed(1) + '%';
                    
                    // Update watchlist
                    updateWatchlist(data.top_symbols);
                    
                    // Update live feed
                    const feedElement = document.getElementById('live-feed');
                    feedElement.textContent = data.live_feed.join('\\n');
                    feedElement.scrollTop = feedElement.scrollHeight;
                    
                    lastUpdateTime = Date.now();
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('connection-status').textContent = 'ERROR';
                    document.getElementById('connection-status').className = 'disconnected';
                });
        }
        
        function updateWatchlist(symbols) {
            const container = document.getElementById('watchlist-grid');
            container.innerHTML = '';
            
            symbols.forEach(symbol => {
                const card = document.createElement('div');
                card.className = 'symbol-card' + (symbol.unusual_activity ? ' active' : '');
                
                card.innerHTML = `
                    <div class="symbol-header">${symbol.symbol}</div>
                    <div>$${symbol.price.toFixed(2)}</div>
                    <div>Smart: ${(symbol.smart_score * 100).toFixed(0)}%</div>
                    ${symbol.unusual_activity ? '<div style="color: #ff6b6b;">🚨 ACTIVITY</div>' : ''}
                `;
                
                container.appendChild(card);
            });
        }
        
        function updateSmartMoneyFlows() {
            fetch('/api/smart-money')
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('smart-money-flows');
                    container.innerHTML = '';
                    
                    if (data.recent_flows.length === 0) {
                        container.innerHTML = '<div style="text-align: center; color: #666;">No recent flows detected</div>';
                        return;
                    }
                    
                    data.recent_flows.slice(-10).forEach(flow => {
                        const item = document.createElement('div');
                        item.className = 'flow-item' + (flow.type === 'institutional' ? ' flow-institutional' : '');
                        
                        const time = new Date(flow.timestamp).toLocaleTimeString();
                        item.innerHTML = `
                            <div><strong>${flow.symbol}</strong> ${flow.type.toUpperCase()}</div>
                            <div>${flow.direction.toUpperCase()} | $${(flow.premium/1000).toFixed(0)}k | ${(flow.confidence*100).toFixed(0)}%</div>
                            <div style="font-size: 10px; color: #666;">${time}</div>
                        `;
                        
                        container.appendChild(item);
                    });
                })
                .catch(error => console.error('Smart money update error:', error));
        }
        
        function startBot() {
            fetch('/api/start').then(() => updateDashboard());
        }
        
        function stopBot() {
            fetch('/api/stop').then(() => updateDashboard());
        }
        
        function refreshData() {
            updateDashboard();
            updateSmartMoneyFlows();
        }
        
        function clearFeed() {
            document.getElementById('live-feed').textContent = '[Feed Cleared] Ready for enhanced trading data...';
        }
        
        // Update intervals
        setInterval(updateDashboard, 3000);        // Main data every 3 seconds
        setInterval(updateSmartMoneyFlows, 5000);  // Smart money every 5 seconds
        
        // Initial load
        updateDashboard();
        updateSmartMoneyFlows();
    </script>
</body>
</html>'''
        
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(html.encode())
    
    def log_message(self, format, *args):
        pass  # Suppress HTTP logs

def start_enhanced_dashboard():
    """Start the enhanced VIX + AD ASTRA dashboard"""
    port = 8892  # Different port from simple bot
    handler = EnhancedDashboardHandler
    httpd = socketserver.TCPServer(("", port), handler)
    
    print("\n" + "="*80)
    print("🚀 VIX + AD ASTRA Enhanced Trading Bot Dashboard")
    print("="*80)
    print(f"🌐 URL: http://localhost:{port}")
    print(f"💰 Portfolio: ${enhanced_bot.portfolio_value:,.2f}")
    print(f"🔗 Alpaca: {'Connected' if enhanced_bot.connected else 'Simulated'}")
    print(f"📊 Watchlist: {len(enhanced_bot.watchlist)} symbols")
    print(f"🧠 Smart Money: {enhanced_bot.smart_money_signals} signals detected")
    print(f"🎯 Features: Multi-Stock | Options Flow | Institutional Tracking")
    print("⏹️ Press Ctrl+C to stop")
    print("="*80)
    
    try:
        webbrowser.open(f'http://localhost:{port}')
    except:
        pass
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Enhanced dashboard stopped")
        enhanced_bot.is_running = False
        httpd.shutdown()

if __name__ == "__main__":
    start_enhanced_dashboard() 