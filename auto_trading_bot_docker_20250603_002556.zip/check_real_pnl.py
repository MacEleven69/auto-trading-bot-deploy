#!/usr/bin/env python3
"""
Check Real Alpaca Account P&L and Trading Activity
"""

import os
from datetime import datetime, date

def check_real_alpaca_pnl():
    print("💰 Checking REAL Alpaca Account P&L...")
    print("=" * 50)
    
    try:
        import alpaca_trade_api as tradeapi
        
        # Connect to Alpaca
        api_key = os.getenv('ALPACA_API_KEY')
        secret_key = os.getenv('ALPACA_SECRET_KEY')
        base_url = os.getenv('ALPACA_BASE_URL', 'https://paper-api.alpaca.markets')
        
        api = tradeapi.REST(api_key, secret_key, base_url, api_version='v2')
        
        # Get account info
        account = api.get_account()
        print(f"📊 Account Status: {account.status}")
        print(f"💵 Portfolio Value: ${float(account.portfolio_value):,.2f}")
        print(f"💸 Cash Balance: ${float(account.cash):,.2f}")
        print(f"🏦 Buying Power: ${float(account.buying_power):,.2f}")
        print()
        
        # Check if account has P&L attributes
        daily_pnl = 0.0
        has_pnl_data = False
        
        # Try different P&L attribute names
        pnl_attrs = [
            ('unrealized_pl', 'Unrealized P&L'),
            ('unrealized_pnl', 'Unrealized P&L'), 
            ('realized_pl', 'Realized P&L'),
            ('realized_pnl', 'Realized P&L'),
            ('total_pl', 'Total P&L'),
            ('total_pnl', 'Total P&L')
        ]
        
        for attr, name in pnl_attrs:
            if hasattr(account, attr):
                value = float(getattr(account, attr))
                print(f"📈 {name}: ${value:+,.2f}")
                daily_pnl += value
                has_pnl_data = True
        
        if has_pnl_data:
            print(f"📊 TOTAL DAILY P&L: ${daily_pnl:+,.2f}")
        else:
            print("⚠️ No P&L data available from account attributes")
        
        print()
        
        # Get current positions
        print("📋 Current Positions:")
        positions = api.list_positions()
        
        if positions:
            total_unrealized = 0.0
            for pos in positions:
                qty = float(pos.qty)
                market_value = float(pos.market_value)
                unrealized_pl = float(pos.unrealized_pl) if hasattr(pos, 'unrealized_pl') else 0.0
                cost_basis = float(pos.cost_basis)
                
                print(f"   {pos.symbol}: {qty:+.0f} shares")
                print(f"      Market Value: ${market_value:,.2f}")
                print(f"      Cost Basis: ${cost_basis:,.2f}")
                print(f"      Unrealized P&L: ${unrealized_pl:+,.2f}")
                print()
                
                total_unrealized += unrealized_pl
            
            print(f"📊 Total Position P&L: ${total_unrealized:+,.2f}")
        else:
            print("   No open positions")
        
        print()
        
        # Get today's orders/activity
        print("📋 Today's Trading Activity:")
        try:
            orders = api.list_orders(
                status='all',
                limit=50,
                after=date.today().isoformat()
            )
            
            if orders:
                filled_orders = [o for o in orders if o.status == 'filled']
                print(f"   Orders today: {len(orders)} total, {len(filled_orders)} filled")
                
                for order in filled_orders[-5:]:  # Last 5 filled orders
                    print(f"   {order.side.upper()} {order.qty} {order.symbol} @ ${float(order.filled_avg_price or 0):.2f}")
            else:
                print("   No orders today")
                
        except Exception as e:
            print(f"   Could not fetch orders: {e}")
        
        print()
        print("=" * 50)
        
        # The key issue
        print("🔍 DIAGNOSIS:")
        if not has_pnl_data:
            print("❌ Your Alpaca API version doesn't provide P&L data")
            print("   The bot is showing SIMULATED trade P&L, not real account P&L")
            print("   Real account changes would show in portfolio value over time")
        else:
            print(f"✅ Real daily P&L: ${daily_pnl:+,.2f}")
            print("   Bot should display this, not simulated trades")
        
        return daily_pnl, has_pnl_data
        
    except Exception as e:
        print(f"❌ Error checking real P&L: {e}")
        return 0.0, False

if __name__ == "__main__":
    check_real_alpaca_pnl() 