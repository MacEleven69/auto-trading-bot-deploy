#!/usr/bin/env python3
"""
Test the auto trading bot functionality
"""

from auto_trading_bot import auto_bot

print("🤖 AUTO TRADING BOT TEST")
print("=" * 40)

# Test market status
market_status = auto_bot.get_market_status()
print(f"Market Status: {market_status['status']}")
print(f"Current Time ET: {market_status['current_time_et']}")
print(f"Is Trading Hours: {market_status['is_trading_hours']}")
print(f"Can Trade: {market_status['can_trade']}")
print()

# Test bot settings
print("🎯 BOT CONFIGURATION:")
print(f"Auto Trading Enabled: {auto_bot.auto_trading_enabled}")
print(f"Real Trading Enabled: {auto_bot.real_trading_enabled}")
print(f"Simulation Mode: {auto_bot.simulation_mode}")
print(f"Market Hours Only: {auto_bot.market_hours_only}")
print(f"Daily Trade Limit: {auto_bot.max_daily_trades}")
print(f"Connected to Alpaca: {auto_bot.connected}")
print()

if auto_bot.connected:
    print("✅ Ready for auto trading!")
else:
    print("❌ Not connected to Alpaca") 