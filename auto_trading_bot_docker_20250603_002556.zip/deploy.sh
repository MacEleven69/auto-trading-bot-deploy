#!/bin/bash
# Docker Auto Trading Bot Deployment Script for Vultr

echo "🐳 Deploying VIX Auto Trading Bot with Docker..."
echo "==============================================="

# Update system
apt update && apt upgrade -y

# Install Docker if not present
if ! command -v docker &> /dev/null; then
    echo "📦 Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    systemctl enable docker
    systemctl start docker
    echo "✅ Docker installed!"
else
    echo "✅ Docker already installed"
fi

# Install Docker Compose if not present
if ! command -v docker-compose &> /dev/null; then
    echo "📦 Installing Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    echo "✅ Docker Compose installed!"
else
    echo "✅ Docker Compose already installed"
fi

# Create application directory
mkdir -p /root/auto_trading_bot
cd /root/auto_trading_bot

# Copy deployment files
cp -r ../vultr_docker_deployment/* .

# Create .env from template
if [ ! -f .env ]; then
    cp .env.template .env
    echo "⚠️  IMPORTANT: Edit .env with your real API keys!"
    echo "   nano .env"
else
    echo "✅ .env file already exists"
fi

# Build and start the container
echo "🚀 Building Docker container..."
docker-compose build

echo "🚀 Starting Auto Trading Bot..."
docker-compose up -d

# Wait a moment for startup
sleep 10

# Check status
echo ""
echo "✅ DEPLOYMENT COMPLETE!"
echo "📊 Dashboard URL: http://$(curl -s ifconfig.me):8893"
echo "🔧 Container status: docker-compose ps"
echo "📋 Container logs: docker-compose logs -f"
echo "🛑 Stop bot: docker-compose down"
echo "🔄 Restart bot: docker-compose restart"
echo ""
echo "⚠️  Don't forget to:"
echo "1. Edit .env with your real API keys: nano .env"
echo "2. Restart container: docker-compose restart"
echo "3. Open firewall port: ufw allow 8893"
