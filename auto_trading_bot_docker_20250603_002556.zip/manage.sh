#!/bin/bash
# Docker Auto Trading Bot Management Script

case "$1" in
    start)
        echo "🚀 Starting Auto Trading Bot..."
        docker-compose up -d
        ;;
    stop)
        echo "🛑 Stopping Auto Trading Bot..."
        docker-compose down
        ;;
    restart)
        echo "🔄 Restarting Auto Trading Bot..."
        docker-compose restart
        ;;
    status)
        echo "📊 Auto Trading Bot Status:"
        docker-compose ps
        ;;
    logs)
        echo "📋 Auto Trading Bot Logs:"
        docker-compose logs -f
        ;;
    update)
        echo "🔄 Updating Auto Trading Bot..."
        docker-compose down
        docker-compose build --no-cache
        docker-compose up -d
        ;;
    dashboard)
        echo "📊 Dashboard URL: http://$(curl -s ifconfig.me):8893"
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|logs|update|dashboard}"
        echo ""
        echo "Commands:"
        echo "  start     - Start the auto trading bot"
        echo "  stop      - Stop the auto trading bot"
        echo "  restart   - Restart the auto trading bot"
        echo "  status    - Show container status"
        echo "  logs      - Show real-time logs"
        echo "  update    - Rebuild and restart container"
        echo "  dashboard - Show dashboard URL"
        exit 1
        ;;
esac
