#!/usr/bin/env python3
"""
Auto Trading Dashboard - Control panel for the automated trading bot
"""

from flask import Flask, render_template_string, jsonify, request
import threading
from auto_trading_bot import auto_bot

app = Flask(__name__)

# HTML Template for Auto Trading Dashboard
AUTO_TRADING_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>🤖 Auto Trading Bot - VIX + AD ASTRA</title>
    <style>
        body {
            background: #0a0a0a;
            color: #00ff00;
            font-family: 'Courier New', monospace;
            margin: 0;
            padding: 20px;
        }
        .header {
            text-align: center;
            border: 2px solid #00ff00;
            padding: 20px;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #001100, #003300);
        }
        .status-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .status-box {
            border: 1px solid #00ff00;
            padding: 15px;
            background: #001100;
            border-radius: 5px;
        }
        .status-title {
            color: #ffff00;
            font-weight: bold;
            margin-bottom: 10px;
            border-bottom: 1px solid #555;
            padding-bottom: 5px;
        }
        .status-line {
            margin: 5px 0;
            padding: 2px;
        }
        .market-open { color: #00ff00; font-weight: bold; }
        .market-closed { color: #ff4444; font-weight: bold; }
        .market-waiting { color: #ffaa00; font-weight: bold; }
        .trading-active { color: #00ff00; background: #002200; padding: 5px; border-radius: 3px; }
        .trading-paused { color: #ff4444; background: #220000; padding: 5px; border-radius: 3px; }
        .control-panel {
            border: 2px solid #ffaa00;
            padding: 20px;
            background: #111100;
            margin-bottom: 20px;
        }
        .control-button {
            background: #003300;
            color: #00ff00;
            border: 1px solid #00ff00;
            padding: 10px 20px;
            margin: 5px;
            cursor: pointer;
            font-family: 'Courier New', monospace;
            border-radius: 3px;
        }
        .control-button:hover {
            background: #005500;
        }
        .danger-button {
            background: #330000;
            color: #ff4444;
            border: 1px solid #ff4444;
        }
        .danger-button:hover {
            background: #550000;
        }
        .log-container {
            height: 300px;
            overflow-y: scroll;
            border: 1px solid #00ff00;
            padding: 10px;
            background: #000;
            font-size: 12px;
        }
        .positive { color: #00ff00; }
        .negative { color: #ff4444; }
        .warning { color: #ffbb00; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🤖 AUTO TRADING BOT</h1>
        <h2>Enhanced VIX + AD ASTRA System</h2>
        <div id="connection-status">🔄 Connecting...</div>
    </div>

    <div class="status-grid">
        <div class="status-box">
            <div class="status-title">📊 MARKET STATUS</div>
            <div class="status-line">Status: <span id="market-status">--</span></div>
            <div class="status-line">Current Time: <span id="current-time">--</span></div>
            <div class="status-line">Trading Hours: <span id="trading-hours">--</span></div>
            <div class="status-line">Can Trade: <span id="can-trade">--</span></div>
        </div>
        
        <div class="status-box">
            <div class="status-title">🤖 BOT STATUS</div>
            <div class="status-line">Mode: <span id="trading-mode">--</span></div>
            <div class="status-line">Auto Trading: <span id="auto-enabled">--</span></div>
            <div class="status-line">Daily Trades: <span id="daily-trades">--</span></div>
            <div class="status-line">Last Update: <span id="last-update">--</span></div>
        </div>
    </div>

    <div class="status-grid">
        <div class="status-box">
            <div class="status-title">💰 PORTFOLIO</div>
            <div class="status-line">Total Value: $<span id="portfolio">--</span></div>
            <div class="status-line">Available Cash: $<span id="cash">--</span></div>
            <div class="status-line">Real Position P&L: $<span id="real-pnl">--</span></div>
            <div class="status-line">Today's Trades P&L: $<span id="trade-pnl">--</span></div>
        </div>
        
        <div class="status-box">
            <div class="status-title">🧠 SMART MONEY</div>
            <div class="status-line">Activity Level: <span id="smart-activity">--</span></div>
            <div class="status-line">Total Premium: $<span id="smart-premium">--</span></div>
            <div class="status-line">Flow Count: <span id="flow-count">--</span></div>
            <div class="status-line">VIX Regime: <span id="vix-regime">--</span></div>
        </div>
    </div>

    <div class="control-panel">
        <div class="status-title">🎛️ CONTROL PANEL</div>
        <button class="control-button" onclick="toggleAutoTrading()">🔄 Toggle Auto Trading</button>
        <button class="control-button" onclick="toggleMarketHours()">⏰ Toggle Market Hours Only</button>
        <button class="control-button danger-button" onclick="emergencyStop()">🛑 EMERGENCY STOP</button>
        <button class="control-button" onclick="resetDailyCounter()">🔄 Reset Daily Counter</button>
    </div>

    <div class="status-box">
        <div class="status-title">📋 RECENT ACTIVITY LOG</div>
        <div class="log-container" id="log-container">
            <div>🔄 Loading recent activity...</div>
        </div>
    </div>

    <script>
        function updateDashboard() {
            fetch('/api/auto_status')
                .then(response => response.json())
                .then(data => {
                    // Market status
                    document.getElementById('market-status').textContent = data.market_status?.status || '--';
                    document.getElementById('current-time').textContent = data.market_status?.current_time_et || '--';
                    document.getElementById('trading-hours').textContent = data.market_status?.is_trading_hours ? 'YES' : 'NO';
                    document.getElementById('can-trade').textContent = data.market_status?.can_trade ? 'YES' : 'NO';
                    
                    // Bot status
                    document.getElementById('trading-mode').textContent = data.simulation_mode ? 'SIMULATION' : 'LIVE TRADING';
                    document.getElementById('auto-enabled').textContent = data.auto_trading_enabled ? 'ENABLED' : 'DISABLED';
                    document.getElementById('daily-trades').textContent = `${data.daily_trade_count}/${data.max_daily_trades}`;
                    document.getElementById('last-update').textContent = new Date().toLocaleTimeString();
                    
                    // Portfolio
                    document.getElementById('portfolio').textContent = data.portfolio_value?.toFixed(2) || '--';
                    document.getElementById('cash').textContent = data.available_cash?.toFixed(2) || '--';
                    const realPnl = document.getElementById('real-pnl');
                    if (data.real_position_pnl !== undefined) {
                        realPnl.textContent = (data.real_position_pnl >= 0 ? '+' : '') + data.real_position_pnl.toFixed(2);
                        realPnl.className = data.real_position_pnl >= 0 ? 'positive' : 'negative';
                    }
                    
                    // Smart money
                    document.getElementById('smart-activity').textContent = data.smart_money_activity || '--';
                    document.getElementById('smart-premium').textContent = data.total_premium?.toLocaleString() || '--';
                    document.getElementById('flow-count').textContent = data.flow_count || '--';
                    document.getElementById('vix-regime').textContent = data.vix_regime || '--';
                    
                    // Connection status
                    const connectionStatus = document.getElementById('connection-status');
                    if (data.connected && data.auto_trading_enabled) {
                        connectionStatus.innerHTML = '🟢 AUTO TRADING ACTIVE';
                        connectionStatus.className = 'trading-active';
                    } else if (data.connected) {
                        connectionStatus.innerHTML = '🟡 CONNECTED - TRADING PAUSED';
                        connectionStatus.className = 'trading-paused';
                    } else {
                        connectionStatus.innerHTML = '🔴 DISCONNECTED';
                        connectionStatus.className = 'trading-paused';
                    }
                })
                .catch(error => {
                    console.error('Dashboard update failed:', error);
                    document.getElementById('connection-status').innerHTML = '❌ CONNECTION ERROR';
                });
        }

        function toggleAutoTrading() {
            fetch('/api/toggle_auto_trading', { method: 'POST' })
                .then(response => response.json())
                .then(data => {
                    alert(`Auto Trading ${data.enabled ? 'ENABLED' : 'DISABLED'}`);
                });
        }

        function toggleMarketHours() {
            fetch('/api/toggle_market_hours', { method: 'POST' })
                .then(response => response.json())
                .then(data => {
                    alert(`Market Hours Only: ${data.enabled ? 'ENABLED' : 'DISABLED'}`);
                });
        }

        function emergencyStop() {
            if (confirm('EMERGENCY STOP: This will immediately halt all trading. Continue?')) {
                fetch('/api/emergency_stop', { method: 'POST' })
                    .then(response => response.json())
                    .then(data => {
                        alert('EMERGENCY STOP ACTIVATED - All trading halted');
                    });
            }
        }

        function resetDailyCounter() {
            fetch('/api/reset_daily_counter', { method: 'POST' })
                .then(response => response.json())
                .then(data => {
                    alert('Daily trade counter reset');
                });
        }

        // Update every 2 seconds
        setInterval(updateDashboard, 2000);
        updateDashboard(); // Initial load
    </script>
</body>
</html>
"""

@app.route('/')
def dashboard():
    return render_template_string(AUTO_TRADING_TEMPLATE)

@app.route('/api/auto_status')
def get_auto_status():
    """Get comprehensive auto trading status"""
    try:
        market_status = auto_bot.get_market_status()
        bot_status = auto_bot.get_enhanced_status()
        
        return jsonify({
            **bot_status,
            'market_status': market_status,
            'auto_trading_enabled': auto_bot.auto_trading_enabled,
            'market_hours_only': auto_bot.market_hours_only,
            'daily_trade_count': auto_bot.daily_trade_count,
            'max_daily_trades': auto_bot.max_daily_trades,
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/toggle_auto_trading', methods=['POST'])
def toggle_auto_trading():
    """Toggle auto trading on/off"""
    auto_bot.auto_trading_enabled = not auto_bot.auto_trading_enabled
    status = "ENABLED" if auto_bot.auto_trading_enabled else "DISABLED"
    auto_bot.log(f"🎛️ Auto Trading {status} via dashboard")
    return jsonify({'enabled': auto_bot.auto_trading_enabled})

@app.route('/api/toggle_market_hours', methods=['POST'])
def toggle_market_hours():
    """Toggle market hours only restriction"""
    auto_bot.market_hours_only = not auto_bot.market_hours_only
    status = "ENABLED" if auto_bot.market_hours_only else "DISABLED"
    auto_bot.log(f"⏰ Market Hours Only {status} via dashboard")
    return jsonify({'enabled': auto_bot.market_hours_only})

@app.route('/api/emergency_stop', methods=['POST'])
def emergency_stop():
    """Emergency stop all trading"""
    auto_bot.auto_trading_enabled = False
    auto_bot.real_trading_enabled = False
    auto_bot.simulation_mode = True
    auto_bot.log("🛑 EMERGENCY STOP ACTIVATED - All trading halted")
    return jsonify({'stopped': True})

@app.route('/api/reset_daily_counter', methods=['POST'])
def reset_daily_counter():
    """Reset daily trade counter"""
    auto_bot.daily_trade_count = 0
    auto_bot.log("🔄 Daily trade counter reset via dashboard")
    return jsonify({'reset': True})

def start_dashboard():
    """Start the auto trading dashboard"""
    print("🚀 Starting Auto Trading Dashboard on http://localhost:8893")
    app.run(host='0.0.0.0', port=8893, debug=False)

if __name__ == "__main__":
    # Start dashboard in a separate thread
    dashboard_thread = threading.Thread(target=start_dashboard, daemon=True)
    dashboard_thread.start()
    
    # Start the auto trading bot
    auto_bot.start_auto_trading() 