#!/usr/bin/env python3
"""
Check API keys and test Alpaca connection
"""

import os
import sys

print("🔍 Checking API Configuration...")
print("=" * 50)

# Check environment variables
alpaca_key = os.getenv('ALPACA_API_KEY')
alpaca_secret = os.getenv('ALPACA_SECRET_KEY')
polygon_key = os.getenv('POLYGON_API_KEY')
base_url = os.getenv('ALPACA_BASE_URL', 'https://paper-api.alpaca.markets')

print(f"ALPACA_API_KEY: {'✅ SET' if alpaca_key else '❌ NOT SET'}")
print(f"ALPACA_SECRET_KEY: {'✅ SET' if alpaca_secret else '❌ NOT SET'}")
print(f"POLYGON_API_KEY: {'✅ SET' if polygon_key else '❌ NOT SET'}")
print(f"ALPACA_BASE_URL: {base_url}")
print()

# Test Alpaca connection
if alpaca_key and alpaca_secret:
    print("🔗 Testing Alpaca Connection...")
    try:
        import alpaca_trade_api as tradeapi
        
        api = tradeapi.REST(alpaca_key, alpaca_secret, base_url, api_version='v2')
        account = api.get_account()
        
        print("✅ ALPACA CONNECTION SUCCESSFUL!")
        print(f"   Account Status: {account.status}")
        print(f"   Portfolio Value: ${float(account.portfolio_value):,.2f}")
        print(f"   Buying Power: ${float(account.buying_power):,.2f}")
        print(f"   Cash: ${float(account.cash):,.2f}")
        
        # Check for newer API attributes
        if hasattr(account, 'unrealized_pl'):
            print(f"   Unrealized P&L: ${float(account.unrealized_pl):,.2f}")
        else:
            print("   ⚠️ No unrealized_pl attribute (older API version)")
            
        if hasattr(account, 'realized_pl'):
            print(f"   Realized P&L: ${float(account.realized_pl):,.2f}")
        else:
            print("   ⚠️ No realized_pl attribute (older API version)")
        
        print()
        print("✅ READY FOR LIVE TRADING!")
        
    except ImportError:
        print("❌ alpaca-trade-api not installed")
        print("   Run: pip install alpaca-trade-api")
    except Exception as e:
        print(f"❌ Alpaca connection failed: {e}")
        print("   Check your API keys and network connection")
else:
    print("❌ Missing Alpaca API credentials")
    print("   Please set ALPACA_API_KEY and ALPACA_SECRET_KEY environment variables")

print()
print("=" * 50) 