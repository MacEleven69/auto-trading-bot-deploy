#!/usr/bin/env python3
"""
VIX + AD ASTRA Enhanced Trading Bot
Combines VIX intelligence with advanced smart money tracking and options flow analysis
"""

import json
import os
import random
import time
import asyncio
from datetime import datetime, timedelta
import http.server
import socketserver
import webbrowser
from threading import Thread
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from enum import Enum
import requests

# Try to import required packages
try:
    import alpaca_trade_api as tradeapi
    ALPACA_AVAILABLE = True
except ImportError:
    ALPACA_AVAILABLE = False

try:
    from polygon import RESTClient
    POLYGON_AVAILABLE = True
except ImportError:
    POLYGON_AVAILABLE = False

# Smart Money Flow Detection Classes
class FlowDirection(Enum):
    BULLISH = "bullish"
    BEARISH = "bearish"
    NEUTRAL = "neutral"

class FlowType(Enum):
    SWEEP = "sweep"
    BLOCK = "block"
    INSTITUTIONAL = "institutional"
    GAMMA_SQUEEZE = "gamma_squeeze"
    UNUSUAL_ACTIVITY = "unusual_activity"

@dataclass
class SmartMoneyFlow:
    symbol: str
    timestamp: datetime
    flow_type: FlowType
    direction: FlowDirection
    premium: float
    volume: int
    confidence: float
    contract_symbol: str = ""
    strike_price: float = 0.0
    expiration_date: str = ""
    details: Dict[str, Any] = None

@dataclass
class WatchlistSymbol:
    symbol: str
    name: str
    sector: str
    current_price: float = 0.0
    volume: int = 0
    smart_money_score: float = 0.0
    unusual_activity: bool = False
    last_flow_detected: Optional[datetime] = None

class VIXAdAstraEnhancedBot:
    """Enhanced VIX + AD ASTRA Trading Bot with Smart Money Tracking"""
    
    def __init__(self):
        # Core connections
        self.api = None
        self.polygon_client = None
        self.connected = False
        
        # Trading mode
        self.simulation_mode = True  # Start in simulation, can be toggled
        self.real_trading_enabled = False
        
        # Portfolio data
        self.portfolio_value = 100399.43
        self.available_cash = -55382.29
        self.positions = []
        self.daily_pnl = 0.0  # Will be real P&L from positions
        self.total_pnl = 0.0  # Running total of simulated trades (if simulation mode)
        self.real_position_pnl = 0.0  # Real unrealized P&L from actual positions
        
        # Market data
        self.spy_price = 592.71
        self.vix_level = 17.43
        
        # Enhanced watchlist (multi-stock)
        self.watchlist = self._initialize_watchlist()
        
        # Smart money tracking
        self.detected_flows: List[SmartMoneyFlow] = []
        self.institutional_activity: List[SmartMoneyFlow] = []
        self.unusual_options_activity = {}
        
        # VIX Intelligence
        self.vix_cache = None
        self.last_vix_request = 0
        self.min_vix_interval = 60
        
        # Trading stats
        self.start_time = datetime.now()
        self.is_running = False
        self.cycle_count = 0
        self.signals_generated = 0
        self.signals_approved = 0
        self.signals_blocked = 0
        self.trades_executed = 0
        self.winning_trades = 0
        self.losing_trades = 0
        
        # Smart money stats
        self.smart_money_signals = 0
        self.institutional_signals = 0
        self.options_flow_signals = 0
        
        # Live feed
        self.live_feed = []
        
        # Initialize systems
        self._connect_apis()
        self._start_enhanced_loops()
    
    def _initialize_watchlist(self):
        """Initialize multi-stock watchlist with smart money tracking"""
        return {
            'SPY': WatchlistSymbol('SPY', 'SPDR S&P 500 ETF', 'ETF'),
            'QQQ': WatchlistSymbol('QQQ', 'Invesco QQQ Trust', 'ETF'),
            'IWM': WatchlistSymbol('IWM', 'iShares Russell 2000 ETF', 'ETF'),
            'AAPL': WatchlistSymbol('AAPL', 'Apple Inc.', 'Technology'),
            'MSFT': WatchlistSymbol('MSFT', 'Microsoft Corporation', 'Technology'),
            'GOOGL': WatchlistSymbol('GOOGL', 'Alphabet Inc.', 'Technology'),
            'TSLA': WatchlistSymbol('TSLA', 'Tesla Inc.', 'Automotive'),
            'NVDA': WatchlistSymbol('NVDA', 'NVIDIA Corporation', 'Technology'),
            'AMD': WatchlistSymbol('AMD', 'Advanced Micro Devices', 'Technology'),
            'META': WatchlistSymbol('META', 'Meta Platforms Inc.', 'Technology'),
            'AMZN': WatchlistSymbol('AMZN', 'Amazon.com Inc.', 'Technology'),
            'NFLX': WatchlistSymbol('NFLX', 'Netflix Inc.', 'Media'),
            'DIS': WatchlistSymbol('DIS', 'The Walt Disney Company', 'Media'),
            'BA': WatchlistSymbol('BA', 'Boeing Company', 'Aerospace'),
            'JPM': WatchlistSymbol('JPM', 'JPMorgan Chase & Co.', 'Financial'),
        }
    
    def _connect_apis(self):
        """Connect to Alpaca and Polygon APIs"""
        # Alpaca connection
        if ALPACA_AVAILABLE:
            api_key = os.getenv('ALPACA_API_KEY')
            secret_key = os.getenv('ALPACA_SECRET_KEY')
            base_url = os.getenv('ALPACA_BASE_URL', 'https://paper-api.alpaca.markets')
            
            if api_key and secret_key:
                try:
                    self.api = tradeapi.REST(api_key, secret_key, base_url, api_version='v2')
                    account = self.api.get_account()
                    self.connected = True
                    self.log(f"✅ ALPACA CONNECTED: {account.status}")
                    self.log(f"💰 Portfolio: ${float(account.portfolio_value):,.2f}")
                    self._update_real_portfolio()
                except Exception as e:
                    self.log(f"❌ Alpaca connection failed: {e}")
            else:
                self.log("⚠️ Alpaca API keys not found")
        
        # Polygon connection for smart money features
        if POLYGON_AVAILABLE:
            polygon_api_key = os.getenv('POLYGON_API_KEY')
            if polygon_api_key:
                try:
                    self.polygon_client = RESTClient(api_key=polygon_api_key)
                    self.log("✅ POLYGON CONNECTED: Smart money tracking enabled")
                except Exception as e:
                    self.log(f"❌ Polygon connection failed: {e}")
            else:
                self.log("⚠️ Polygon API key not found - limited smart money features")
    
    def _start_enhanced_loops(self):
        """Start all enhanced monitoring loops"""
        Thread(target=self._market_data_loop, daemon=True).start()
        Thread(target=self._smart_money_loop, daemon=True).start()
        Thread(target=self._options_flow_loop, daemon=True).start()
        Thread(target=self._trading_loop, daemon=True).start()
        self.log("🚀 ENHANCED VIX + AD ASTRA BOT INITIALIZED")
        self.log("🎯 Features: Smart Money Tracking | Options Flow | Multi-Stock Watchlist")
    
    def _market_data_loop(self):
        """Enhanced market data loop with multi-stock monitoring"""
        while True:
            try:
                # Update all watchlist symbols
                for symbol in list(self.watchlist.keys())[:5]:  # Process 5 at a time
                    self._update_symbol_data(symbol)
                    time.sleep(1)  # Rate limiting
                
                # Update VIX with enhanced method
                self.vix_level = self._get_enhanced_vix_data()
                
                # Log market summary
                active_symbols = len([s for s in self.watchlist.values() if s.current_price > 0])
                self.log(f"📈 MARKET UPDATE: {active_symbols} symbols tracked | VIX={self.vix_level:.2f}")
                
            except Exception as e:
                self.log(f"⚠️ Market data error: {e}")
            
            time.sleep(15)  # Update every 15 seconds
    
    def _smart_money_loop(self):
        """Smart money detection loop"""
        while True:
            try:
                # Scan watchlist for smart money activity
                for symbol in self.watchlist.keys():
                    flows = self._detect_smart_money_flow(symbol)
                    if flows:
                        self.detected_flows.extend(flows)
                        self._process_smart_money_signals(flows)
                
                # Update smart money scores
                self._update_smart_money_scores()
                
            except Exception as e:
                self.log(f"⚠️ Smart money detection error: {e}")
            
            time.sleep(30)  # Check every 30 seconds
    
    def _options_flow_loop(self):
        """Options flow analysis loop"""
        while True:
            try:
                # Analyze options flow for high-priority symbols
                priority_symbols = ['SPY', 'QQQ', 'AAPL', 'TSLA', 'NVDA']
                
                for symbol in priority_symbols:
                    flows = self._analyze_options_flow(symbol)
                    if flows:
                        self.options_flow_signals += len(flows)
                        self._process_options_signals(flows)
                
            except Exception as e:
                self.log(f"⚠️ Options flow error: {e}")
            
            time.sleep(45)  # Check every 45 seconds
    
    def _trading_loop(self):
        """Enhanced trading loop with smart money integration"""
        while True:
            if self.is_running:
                self.cycle_count += 1
                self._execute_enhanced_cycle()
            time.sleep(8)  # 8-second cycles when running
    
    def _update_symbol_data(self, symbol: str):
        """Update market data for a watchlist symbol"""
        try:
            # Get real-time price data
            price = self._get_symbol_price(symbol)
            if price:
                self.watchlist[symbol].current_price = price
                
                # Update SPY specifically for VIX correlation
                if symbol == 'SPY':
                    self.spy_price = price
                    
        except Exception as e:
            self.log(f"⚠️ Error updating {symbol}: {e}")
    
    def _get_symbol_price(self, symbol: str) -> Optional[float]:
        """Get current price for a symbol using multiple methods"""
        # Method 1: Polygon API
        if self.polygon_client:
            try:
                response = requests.get(
                    f"https://api.polygon.io/v2/aggs/ticker/{symbol}/prev?adjusted=true&apikey={os.getenv('POLYGON_API_KEY')}",
                    timeout=5
                )
                if response.status_code == 200:
                    data = response.json()
                    if data.get('results'):
                        return float(data['results'][0]['c'])
            except Exception as e:
                pass
        
        # Method 2: Alpaca
        if self.api and self.connected:
            try:
                quote = self.api.get_latest_quote(symbol)
                if quote and quote.ask_price:
                    return float(quote.ask_price)
            except Exception as e:
                pass
        
        # Method 3: Simulation based on current price
        if self.watchlist[symbol].current_price > 0:
            change = random.uniform(-0.02, 0.02)  # ±2% change
            return self.watchlist[symbol].current_price * (1 + change)
        
        # Default prices for major symbols
        defaults = {
            'SPY': 592.71, 'QQQ': 485.20, 'IWM': 218.45, 'AAPL': 189.75,
            'MSFT': 415.30, 'GOOGL': 175.85, 'TSLA': 248.50, 'NVDA': 875.25,
            'AMD': 152.40, 'META': 485.60, 'AMZN': 178.90, 'NFLX': 645.80
        }
        return defaults.get(symbol, 100.0)
    
    def _get_enhanced_vix_data(self) -> float:
        """Enhanced VIX data with smart caching and correlation"""
        current_time = time.time()
        
        # Check cache first (1-minute caching)
        if hasattr(self, '_last_vix_request') and hasattr(self, '_vix_cache'):
            if current_time - self._last_vix_request < self.min_vix_interval:
                return self._vix_cache
        
        # Try Polygon VIX API
        polygon_api_key = os.getenv('POLYGON_API_KEY')
        if polygon_api_key:
            try:
                response = requests.get(
                    f"https://api.polygon.io/v2/aggs/ticker/VIX/prev?adjusted=true&apikey={polygon_api_key}",
                    timeout=5
                )
                if response.status_code == 200:
                    data = response.json()
                    if data.get('results'):
                        vix_level = float(data['results'][0]['c'])
                        self._last_vix_request = current_time
                        self._vix_cache = vix_level
                        return vix_level
            except Exception as e:
                pass
        
        # Enhanced VIX simulation with smart money correlation
        base_vix = 16.5
        
        # Factor in smart money activity
        recent_flows = [f for f in self.detected_flows 
                       if (datetime.now() - f.timestamp).seconds < 3600]  # Last hour
        
        if recent_flows:
            avg_confidence = sum(f.confidence for f in recent_flows) / len(recent_flows)
            institutional_count = len([f for f in recent_flows if f.flow_type == FlowType.INSTITUTIONAL])
            
            # Higher institutional activity can indicate market stress
            if institutional_count > 3:
                base_vix += 2.0  # Institutional activity suggests uncertainty
            
            # High confidence flows might reduce VIX
            if avg_confidence > 0.8:
                base_vix -= 1.0
        
        # SPY correlation
        if hasattr(self, 'spy_price') and self.spy_price:
            spy_change = (self.spy_price - 590) / 590
            if spy_change > 0.01:
                base_vix -= 1.5  # SPY up, VIX down
            elif spy_change < -0.01:
                base_vix += 2.0  # SPY down, VIX up
        
        # Add realistic variation
        variation = random.uniform(-2, 2)
        vix_estimate = max(9, min(35, base_vix + variation))
        
        self._last_vix_request = current_time
        self._vix_cache = round(vix_estimate, 2)
        return self._vix_cache
    
    def _detect_smart_money_flow(self, symbol: str) -> List[SmartMoneyFlow]:
        """Detect smart money flow for a symbol"""
        flows = []
        
        # Simulate smart money detection (30% chance)
        if random.random() < 0.30:
            flow_type = random.choice(list(FlowType))
            direction = random.choice(list(FlowDirection))
            
            # Generate realistic premium based on flow type
            if flow_type == FlowType.INSTITUTIONAL:
                premium = random.uniform(500000, 2000000)  # $500k - $2M
                self.institutional_signals += 1
            elif flow_type == FlowType.BLOCK:
                premium = random.uniform(200000, 800000)   # $200k - $800k
            else:
                premium = random.uniform(50000, 300000)    # $50k - $300k
            
            confidence = random.uniform(0.65, 0.95)
            
            flow = SmartMoneyFlow(
                symbol=symbol,
                timestamp=datetime.now(),
                flow_type=flow_type,
                direction=direction,
                premium=premium,
                volume=random.randint(100, 1500),
                confidence=confidence,
                contract_symbol=f"{symbol}{random.randint(240101, 241231)}C{random.randint(150, 250)}000",
                strike_price=random.uniform(150, 250),
                expiration_date=(datetime.now() + timedelta(days=random.randint(1, 60))).strftime('%Y-%m-%d')
            )
            
            flows.append(flow)
            self.smart_money_signals += 1
            
            # Track institutional activity separately
            if flow_type == FlowType.INSTITUTIONAL:
                self.institutional_activity.append(flow)
        
        return flows
    
    def _analyze_options_flow(self, symbol: str) -> List[SmartMoneyFlow]:
        """Analyze options flow patterns for unusual activity"""
        flows = []
        
        # Simulate options flow analysis (25% chance)
        if random.random() < 0.25:
            # Check for unusual volume patterns
            if random.random() < 0.4:  # 40% chance of unusual activity
                flow = SmartMoneyFlow(
                    symbol=symbol,
                    timestamp=datetime.now(),
                    flow_type=FlowType.UNUSUAL_ACTIVITY,
                    direction=random.choice(list(FlowDirection)),
                    premium=random.uniform(100000, 500000),
                    volume=random.randint(500, 2000),  # High volume
                    confidence=random.uniform(0.70, 0.90),
                    details={
                        'volume_ratio': random.uniform(3.0, 8.0),  # 3-8x normal volume
                        'avg_premium': random.uniform(2.5, 15.0),
                        'unusual_pattern': random.choice(['sweep', 'block', 'gamma_ramp'])
                    }
                )
                flows.append(flow)
        
        return flows
    
    def _process_smart_money_signals(self, flows: List[SmartMoneyFlow]):
        """Process detected smart money signals"""
        for flow in flows:
            # Update watchlist symbol
            if flow.symbol in self.watchlist:
                self.watchlist[flow.symbol].smart_money_score = min(1.0, 
                    self.watchlist[flow.symbol].smart_money_score + (flow.confidence * 0.1))
                self.watchlist[flow.symbol].last_flow_detected = flow.timestamp
                
                if flow.flow_type in [FlowType.INSTITUTIONAL, FlowType.UNUSUAL_ACTIVITY]:
                    self.watchlist[flow.symbol].unusual_activity = True
            
            # Log significant flows
            if flow.premium >= 500000:  # $500k+
                self.log(f"🔥 MAJOR FLOW DETECTED: {flow.symbol}")
                self.log(f"   💰 Premium: ${flow.premium:,.0f} | Type: {flow.flow_type.value}")
                self.log(f"   📊 Direction: {flow.direction.value} | Confidence: {flow.confidence:.1%}")
    
    def _process_options_signals(self, flows: List[SmartMoneyFlow]):
        """Process options flow signals"""
        for flow in flows:
            self.log(f"⚡ OPTIONS FLOW: {flow.symbol}")
            self.log(f"   📈 Volume: {flow.volume} contracts | Premium: ${flow.premium:,.0f}")
            if flow.details:
                self.log(f"   🔍 Pattern: {flow.details.get('unusual_pattern', 'N/A')}")
    
    def _update_smart_money_scores(self):
        """Update smart money scores for all watchlist symbols"""
        # Decay scores over time
        for symbol_data in self.watchlist.values():
            if symbol_data.last_flow_detected:
                hours_since = (datetime.now() - symbol_data.last_flow_detected).total_seconds() / 3600
                if hours_since > 4:  # Decay after 4 hours
                    symbol_data.smart_money_score *= 0.95
                    if symbol_data.smart_money_score < 0.1:
                        symbol_data.unusual_activity = False
    
    def _execute_enhanced_cycle(self):
        """Execute enhanced trading cycle with smart money integration"""
        self.log(f"🔄 ===== ENHANCED CYCLE #{self.cycle_count} START =====")
        
        # Step 1: Update portfolio
        self._update_portfolio_data()
        
        # Step 2: VIX regime analysis
        regime = self._analyze_vix_regime()
        
        # Step 3: Smart money analysis
        smart_summary = self._analyze_smart_money_activity()
        
        # Step 4: Generate enhanced signal
        signal = self._generate_enhanced_signal(regime, smart_summary)
        
        # Step 5: Apply multi-factor filtering
        decision = self._apply_enhanced_filters(signal, regime, smart_summary)
        
        # Step 6: Execute if approved
        if decision['execute']:
            self._execute_enhanced_trade(decision)
        
        # Step 7: Update statistics
        self._update_enhanced_stats()
        
        self.log(f"✅ ===== ENHANCED CYCLE #{self.cycle_count} COMPLETE =====")
    
    def _analyze_vix_regime(self):
        """Enhanced VIX regime analysis"""
        if self.vix_level < 12:
            regime = "ULTRA_LOW_VOL"
            risk_level = "MINIMAL"
        elif self.vix_level < 15:
            regime = "LOW_VOLATILITY"
            risk_level = "LOW"
        elif self.vix_level < 20:
            regime = "NORMAL_MARKET"
            risk_level = "MODERATE"
        elif self.vix_level < 30:
            regime = "ELEVATED_STRESS"
            risk_level = "HIGH"
        else:
            regime = "CRISIS_MODE"
            risk_level = "EXTREME"
        
        self.log(f"🔥 VIX REGIME: {self.vix_level:.2f} → {regime} (Risk: {risk_level})")
        return {'regime': regime, 'risk': risk_level, 'vix': self.vix_level}
    
    def _analyze_smart_money_activity(self):
        """Analyze recent smart money activity"""
        recent_cutoff = datetime.now() - timedelta(hours=2)
        recent_flows = [f for f in self.detected_flows if f.timestamp >= recent_cutoff]
        
        if not recent_flows:
            return {'activity_level': 'quiet', 'dominant_direction': 'neutral', 'confidence': 0.0}
        
        # Calculate metrics
        total_premium = sum(f.premium for f in recent_flows)
        avg_confidence = sum(f.confidence for f in recent_flows) / len(recent_flows)
        
        bullish_flows = len([f for f in recent_flows if f.direction == FlowDirection.BULLISH])
        bearish_flows = len([f for f in recent_flows if f.direction == FlowDirection.BEARISH])
        
        # Determine activity level
        if total_premium > 5000000:  # $5M+
            activity_level = 'extremely_high'
        elif total_premium > 2000000:  # $2M+
            activity_level = 'high'
        elif total_premium > 500000:   # $500k+
            activity_level = 'moderate'
        else:
            activity_level = 'low'
        
        # Determine dominant direction
        if bullish_flows > bearish_flows * 1.5:
            dominant_direction = 'bullish'
        elif bearish_flows > bullish_flows * 1.5:
            dominant_direction = 'bearish'
        else:
            dominant_direction = 'neutral'
        
        summary = {
            'activity_level': activity_level,
            'dominant_direction': dominant_direction,
            'confidence': avg_confidence,
            'total_premium': total_premium,
            'flow_count': len(recent_flows)
        }
        
        self.log(f"🧠 SMART MONEY: {activity_level} activity | Direction: {dominant_direction}")
        self.log(f"   💰 Total Premium: ${total_premium:,.0f} | Flows: {len(recent_flows)}")
        
        return summary
    
    def _generate_enhanced_signal(self, regime, smart_summary):
        """Generate enhanced signal incorporating smart money data"""
        # Base signal generation (40% chance with smart money boost)
        base_probability = 0.40
        
        # Boost probability based on smart money activity
        if smart_summary['activity_level'] in ['high', 'extremely_high']:
            base_probability += 0.20
        elif smart_summary['activity_level'] == 'moderate':
            base_probability += 0.10
        
        if random.random() < base_probability:
            self.signals_generated += 1
            
            # Choose primary symbol based on smart money activity
            symbols_with_activity = [s for s, data in self.watchlist.items() 
                                   if data.smart_money_score > 0.3]
            
            if symbols_with_activity and random.random() < 0.7:
                primary_symbol = random.choice(symbols_with_activity)
            else:
                primary_symbol = 'SPY'  # Default fallback
            
            # Signal direction influenced by smart money
            if smart_summary['dominant_direction'] == 'bullish' and random.random() < 0.7:
                actions = ['BUY_CALL', 'SELL_PUT']
            elif smart_summary['dominant_direction'] == 'bearish' and random.random() < 0.7:
                actions = ['BUY_PUT', 'SELL_CALL']
            else:
                actions = ['BUY_CALL', 'BUY_PUT', 'SELL_CALL', 'SELL_PUT']
            
            # Enhanced confidence calculation
            base_confidence = random.uniform(60, 90)
            smart_money_boost = smart_summary['confidence'] * 10  # 0-10 point boost
            vix_adjustment = max(-5, min(5, (20 - regime['vix']) / 2))  # VIX adjustment
            
            final_confidence = min(95, base_confidence + smart_money_boost + vix_adjustment)
            
            signal = {
                'id': f"ENHANCED-{self.signals_generated:04d}",
                'symbol': primary_symbol,
                'action': random.choice(actions),
                'confidence': final_confidence,
                'entry_price': self.watchlist[primary_symbol].current_price + random.uniform(-2, 2),
                'target_price': self.watchlist[primary_symbol].current_price + random.uniform(-5, 5),
                'stop_loss': self.watchlist[primary_symbol].current_price + random.uniform(-3, 3),
                'size': random.randint(1, 10),
                'reasoning': self._generate_enhanced_reasoning(regime, smart_summary),
                'timeframe': random.choice(['5m', '15m', '1h', '4h']),
                'smart_money_factor': smart_summary['activity_level'],
                'vix_factor': regime['regime']
            }
            
            self.log(f"⚡ ENHANCED SIGNAL #{signal['id']}")
            self.log(f"   📋 {signal['action']} {signal['size']} {signal['symbol']}")
            self.log(f"   🎯 Confidence: {signal['confidence']:.1f}% | Entry: ${signal['entry_price']:.2f}")
            self.log(f"   🧠 Smart Money: {signal['smart_money_factor']} | VIX: {signal['vix_factor']}")
            self.log(f"   💡 Reasoning: {signal['reasoning']}")
            
            return signal
        
        return None
    
    def _generate_enhanced_reasoning(self, regime, smart_summary):
        """Generate enhanced reasoning incorporating multiple factors"""
        reasons = []
        
        # VIX-based reasoning
        if regime['risk'] == 'MINIMAL':
            reasons.append("Ultra-low volatility environment favors risk-on strategies")
        elif regime['risk'] == 'EXTREME':
            reasons.append("Crisis-level VIX suggests defensive positioning")
        
        # Smart money reasoning
        if smart_summary['activity_level'] in ['high', 'extremely_high']:
            reasons.append(f"Heavy institutional flow ({smart_summary['flow_count']} signals)")
        
        if smart_summary['dominant_direction'] != 'neutral':
            reasons.append(f"Smart money showing {smart_summary['dominant_direction']} bias")
        
        # Technical reasoning
        technical_reasons = [
            "Options flow momentum building",
            "Unusual volume in key strikes",
            "Cross-asset correlation signal",
            "Gamma positioning shift detected",
            "Institutional hedging pattern"
        ]
        reasons.append(random.choice(technical_reasons))
        
        return " | ".join(reasons)
    
    def _apply_enhanced_filters(self, signal, regime, smart_summary):
        """Apply enhanced multi-factor filtering"""
        if not signal:
            self.log("⏸️  ENHANCED FILTER: No signal to analyze")
            return {'execute': False, 'reason': 'No signal generated'}
        
        self.log(f"🧠 ENHANCED FILTERING:")
        self.log(f"   📊 Signal: {signal['action']} {signal['symbol']} | Confidence: {signal['confidence']:.1f}%")
        self.log(f"   🔥 VIX: {regime['regime']} | Smart Money: {smart_summary['activity_level']}")
        
        # Filter 1: Dynamic confidence thresholds
        vix_thresholds = {
            'ULTRA_LOW_VOL': 60,
            'LOW_VOLATILITY': 65,
            'NORMAL_MARKET': 70,
            'ELEVATED_STRESS': 80,
            'CRISIS_MODE': 90
        }
        
        # Adjust threshold based on smart money activity
        required_confidence = vix_thresholds.get(regime['regime'], 70)
        if smart_summary['activity_level'] in ['high', 'extremely_high']:
            required_confidence -= 10  # Lower threshold with strong smart money signal
        
        if signal['confidence'] < required_confidence:
            self.signals_blocked += 1
            self.log(f"🚫 CONFIDENCE FILTER: {signal['confidence']:.1f}% < {required_confidence}% required")
            return {'execute': False, 'reason': f'Confidence too low for current conditions'}
        
        # Filter 2: Smart money alignment
        if smart_summary['dominant_direction'] != 'neutral':
            signal_bullish = signal['action'] in ['BUY_CALL', 'SELL_PUT']
            smart_bullish = smart_summary['dominant_direction'] == 'bullish'
            
            if signal_bullish != smart_bullish and smart_summary['confidence'] > 0.8:
                self.signals_blocked += 1
                self.log(f"🚫 SMART MONEY MISALIGNMENT: Signal conflicts with high-confidence flows")
                return {'execute': False, 'reason': 'Smart money directional conflict'}
        
        # Filter 3: Enhanced position sizing
        base_multiplier = 1.0
        
        # VIX-based sizing
        vix_multipliers = {
            'ULTRA_LOW_VOL': 1.5,
            'LOW_VOLATILITY': 1.2,
            'NORMAL_MARKET': 1.0,
            'ELEVATED_STRESS': 0.7,
            'CRISIS_MODE': 0.3
        }
        
        # Smart money boost
        smart_multipliers = {
            'extremely_high': 1.3,
            'high': 1.1,
            'moderate': 1.0,
            'low': 0.9,
            'quiet': 0.8
        }
        
        vix_mult = vix_multipliers.get(regime['regime'], 1.0)
        smart_mult = smart_multipliers.get(smart_summary['activity_level'], 1.0)
        
        final_multiplier = vix_mult * smart_mult
        adjusted_size = max(1, int(signal['size'] * final_multiplier))
        
        self.signals_approved += 1
        self.log(f"✅ ENHANCED FILTER: Signal APPROVED")
        self.log(f"   📏 Size: {signal['size']} → {adjusted_size} (VIX×{vix_mult:.1f} | Smart×{smart_mult:.1f})")
        self.log(f"   ✨ Multi-factor analysis supports execution")
        
        return {
            'execute': True,
            'signal': signal,
            'adjusted_size': adjusted_size,
            'regime': regime,
            'smart_summary': smart_summary,
            'multiplier': final_multiplier,
            'reason': f'Approved: VIX {regime["regime"]} + Smart Money {smart_summary["activity_level"]}'
        }
    
    def _execute_enhanced_trade(self, decision):
        """Execute enhanced trade with detailed logging"""
        signal = decision['signal']
        size = decision['adjusted_size']
        self.trades_executed += 1
        
        # Enhanced execution simulation
        slippage = random.uniform(-0.30, 0.30)
        execution_price = signal['entry_price'] + slippage
        
        # Smart money influenced success rate
        base_success_rate = 0.75
        
        # Adjust based on smart money alignment
        if decision['smart_summary']['activity_level'] in ['high', 'extremely_high']:
            base_success_rate += 0.10
        
        # Adjust based on VIX conditions
        if decision['regime']['risk'] in ['MINIMAL', 'LOW']:
            base_success_rate += 0.05
        elif decision['regime']['risk'] == 'EXTREME':
            base_success_rate -= 0.10
        
        success = random.random() < base_success_rate
        
        if success:
            self.winning_trades += 1
            # Enhanced P&L calculation
            base_pnl = random.uniform(20, 150)
            
            # Smart money boost
            if decision['smart_summary']['activity_level'] == 'extremely_high':
                base_pnl *= random.uniform(1.2, 1.8)
            
            pnl = base_pnl
            self.total_pnl += pnl
            
            self.log(f"✅ ENHANCED TRADE SUCCESS:")
            self.log(f"   📈 {signal['action']} {size} {signal['symbol']} @ ${execution_price:.2f}")
            self.log(f"   💰 P&L: +${pnl:.2f} | Total: +${self.total_pnl:.2f}")
            self.log(f"   🎯 Smart Money Factor: {decision['smart_summary']['activity_level']}")
        else:
            self.losing_trades += 1
            pnl = -random.uniform(25, 90)
            self.total_pnl += pnl
            
            self.log(f"❌ TRADE LOSS:")
            self.log(f"   📉 {signal['action']} {size} {signal['symbol']} @ ${execution_price:.2f}")
            self.log(f"   💸 P&L: ${pnl:.2f} | Total: ${self.total_pnl:+.2f}")
        
        # Update portfolio
        self.portfolio_value += pnl
        self.daily_pnl += pnl
    
    def _update_portfolio_data(self):
        """Update portfolio with real or simulated data"""
        if self.connected:
            self._update_real_portfolio()
        else:
            # Simulate portfolio changes
            drift = random.uniform(-75, 75)
            self.portfolio_value += drift
            self.daily_pnl += drift
        
        # Clear, differentiated logging
        if self.simulation_mode:
            self.log(f"📊 PORTFOLIO STATUS:")
            self.log(f"   💰 REAL Alpaca: ${self.portfolio_value:,.2f} | Real P&L: ${self.daily_pnl:+.2f}")
            self.log(f"   🎮 SIMULATION: Fake trades P&L: ${self.total_pnl:+.2f}")
        else:
            self.log(f"💰 LIVE TRADING: ${self.portfolio_value:,.2f} | Daily P&L: ${self.daily_pnl:+.2f}")
    
    def _update_real_portfolio(self):
        """Update from real Alpaca account"""
        try:
            account = self.api.get_account()
            self.portfolio_value = float(account.portfolio_value)
            self.available_cash = float(account.cash)
            
            # Get real positions and calculate actual P&L
            positions = self.api.list_positions()
            self.positions = []
            self.real_position_pnl = 0.0
            
            for pos in positions:
                pos_data = {
                    'symbol': pos.symbol,
                    'qty': float(pos.qty),
                    'market_value': float(pos.market_value),
                    'cost_basis': float(pos.cost_basis),
                    'unrealized_pnl': float(pos.unrealized_pl) if hasattr(pos, 'unrealized_pl') else 0.0
                }
                self.positions.append(pos_data)
                self.real_position_pnl += pos_data['unrealized_pnl']
            
            # Use real position P&L as daily P&L (since API doesn't provide daily P&L directly)
            self.daily_pnl = self.real_position_pnl
            
            self.log(f"💰 REAL ACCOUNT - Portfolio: ${self.portfolio_value:,.2f} | Position P&L: ${self.real_position_pnl:+.2f}")
            if self.simulation_mode:
                self.log(f"🎮 SIMULATION - Simulated P&L: ${self.total_pnl:+.2f}")
                
        except Exception as e:
            self.log(f"❌ Portfolio update failed: {e}")
    
    def _update_enhanced_stats(self):
        """Update enhanced performance statistics"""
        if self.trades_executed > 0:
            win_rate = (self.winning_trades / self.trades_executed) * 100
            avg_pnl = self.total_pnl / self.trades_executed
            approval_rate = (self.signals_approved / max(1, self.signals_generated)) * 100
            
            # Smart money metrics
            institutional_rate = (self.institutional_signals / max(1, self.smart_money_signals)) * 100
            
            self.log(f"📊 ENHANCED PERFORMANCE:")
            self.log(f"   🎯 Win Rate: {win_rate:.1f}% | Avg P&L: ${avg_pnl:.2f}")
            self.log(f"   🧠 Signal Approval: {approval_rate:.1f}% | Smart Money: {self.smart_money_signals}")
            self.log(f"   🏛️ Institutional Rate: {institutional_rate:.1f}% | Options Flow: {self.options_flow_signals}")
    
    def log(self, message):
        """Enhanced logging with timestamp"""
        timestamp = datetime.now().strftime('%H:%M:%S.%f')[:-3]
        entry = f"[{timestamp}] {message}"
        self.live_feed.append(entry)
        
        if len(self.live_feed) > 200:  # Increased capacity
            self.live_feed.pop(0)
        
        print(entry)
    
    def get_enhanced_status(self):
        """Get comprehensive enhanced bot status"""
        uptime = str(datetime.now() - self.start_time).split('.')[0]
        win_rate = (self.winning_trades / max(1, self.trades_executed)) * 100
        approval_rate = (self.signals_approved / max(1, self.signals_generated)) * 100
        
        # Smart money summary
        active_symbols = len([s for s in self.watchlist.values() if s.smart_money_score > 0.2])
        unusual_activity_count = len([s for s in self.watchlist.values() if s.unusual_activity])
        
        # Recent flows summary
        recent_flows = [f for f in self.detected_flows 
                       if (datetime.now() - f.timestamp).seconds < 3600]
        
        return {
            'timestamp': datetime.now().isoformat(),
            'connected': self.connected,
            'running': self.is_running,
            'uptime': uptime,
            'cycle_count': self.cycle_count,
            'simulation_mode': self.simulation_mode,
            
            # Portfolio - distinguish real vs simulated
            'portfolio_value': self.portfolio_value,  # Real Alpaca value
            'available_cash': self.available_cash,    # Real Alpaca cash
            'daily_pnl': self.daily_pnl,            # Real position P&L
            'total_pnl': self.total_pnl,            # Simulated trades P&L
            'real_position_pnl': self.real_position_pnl,  # Real unrealized P&L
            'positions': self.positions,              # Real positions
            
            # Market data
            'spy_price': self.spy_price,
            'vix_level': self.vix_level,
            'watchlist_count': len(self.watchlist),
            'active_symbols': active_symbols,
            
            # Trading stats
            'signals_generated': self.signals_generated,
            'signals_approved': self.signals_approved,
            'signals_blocked': self.signals_blocked,
            'trades_executed': self.trades_executed,
            'winning_trades': self.winning_trades,
            'losing_trades': self.losing_trades,
            'win_rate': win_rate,
            'approval_rate': approval_rate,
            
            # Enhanced smart money stats
            'smart_money_signals': self.smart_money_signals,
            'institutional_signals': self.institutional_signals,
            'options_flow_signals': self.options_flow_signals,
            'unusual_activity_symbols': unusual_activity_count,
            'recent_flows_count': len(recent_flows),
            
            # Watchlist preview
            'top_symbols': [
                {
                    'symbol': symbol,
                    'price': data.current_price,
                    'smart_score': data.smart_money_score,
                    'unusual_activity': data.unusual_activity
                }
                for symbol, data in sorted(
                    self.watchlist.items(), 
                    key=lambda x: x[1].smart_money_score, 
                    reverse=True
                )[:8]
            ],
            
            # Live feed
            'live_feed': self.live_feed[-80:]  # More feed history
        }

# Global enhanced bot instance
enhanced_bot = VIXAdAstraEnhancedBot() 